import json
import re

# Читаем файл
with open('text скрипта.txt', 'r', encoding='utf-8') as f:
    content = f.read()

# Ищем все пары вопрос-ответ
pattern = r'"([^"]+)",\s*answer:\s*"([^"]+)"'
matches = re.findall(pattern, content)

# Создаем структуру JSON
quiz_data = {
    'quiz_database': []
}

for question, answer in matches:
    quiz_data['quiz_database'].append({
        'question': question,
        'correct_answer': answer
    })

# Сохраняем в JSON
with open('quiz_answers.json', 'w', encoding='utf-8') as f:
    json.dump(quiz_data, f, ensure_ascii=False, indent=2)

print(f'✅ Создано {len(quiz_data["quiz_database"])} вопросов!')
print(f'📝 Примеры:')
for i, item in enumerate(quiz_data['quiz_database'][:3]):
    print(f'{i+1}. Q: {item["question"][:60]}...')
    print(f'   A: {item["correct_answer"]}')

const fs = require('fs');

// Читаем файл
const content = fs.readFileSync('text скрипта.txt', 'utf-8');
const lines = content.split('\n');

console.log(`Всего строк: ${lines.length}`);
console.log('Первые 3 строки:');
for (let i = 0; i < 3; i++) {
    console.log(`${i}: [${lines[i]}]`);
    console.log(`   Длина: ${lines[i].length}`);
    console.log(`   Содержит ", answer:": ${lines[i].includes(', answer:')}`);
}

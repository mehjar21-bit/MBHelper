// quizOverlay.js - Безопасная система подсказок для квиза (БЕЗ автоматических запросов!)
import { log, logWarn, logError, waitForElements, isExtensionContextValid } from './utils.js';

let quizDatabase = null;

// Загрузка базы данных с вопросами
const loadQuizDatabase = async () => {
    if (quizDatabase) return quizDatabase;
    
    try {
        const url = chrome.runtime.getURL('quiz_answers.json');
        const response = await fetch(url);
        quizDatabase = await response.json();
        log(`Загружено ${quizDatabase.quiz_database.length} вопросов квиза`);
        return quizDatabase;
    } catch (error) {
        logError('Не удалось загрузить базу вопросов:', error);
        return null;
    }
};

// Нормализация текста для корректного сравнения
const normalizeText = (text) => {
    return text.trim()
        .toLowerCase()
        .replace(/\s+/g, ' ')
        .replace(/[.,!?;:«»""]/g, '');
};

// Поиск правильного ответа в базе
const findCorrectAnswer = (questionText) => {
    if (!quizDatabase || !quizDatabase.quiz_database) return null;
    
    const normalizedQuestion = normalizeText(questionText);
    
    const match = quizDatabase.quiz_database.find(item => {
        return normalizeText(item.question) === normalizedQuestion;
    });
    
    if (match) {
        log(`Найден ответ: "${match.correct_answer}"`);
    } else {
        logWarn(`Вопрос не найден в базе: "${questionText.substring(0, 80)}..."`);
    }
    
    return match ? match.correct_answer : null;
};

// Создание визуальной подсказки (overlay)
const createAnswerOverlay = (answerElement, subtleMode = false) => {
    // Удаляем старые подсказки
    document.querySelectorAll('.quiz-helper-overlay').forEach(el => el.remove());
    document.querySelectorAll('.quiz-answer-highlighted').forEach(el => {
        el.classList.remove('quiz-answer-highlighted');
        el.style.boxShadow = '';
        el.style.border = '';
    });
    
    answerElement.classList.add('quiz-answer-highlighted');
    answerElement.style.position = 'relative';
    
    if (subtleMode) {
        // Тонкая подсветка (менее заметная)
        answerElement.style.border = '2px solid rgba(0, 255, 0, 0.4)';
        answerElement.style.boxShadow = '0 0 8px rgba(0, 255, 0, 0.3)';
    } else {
        // Яркая подсветка БЕЗ иконок и символов - только рамка
        answerElement.style.border = '3px solid #00ff00';
        answerElement.style.boxShadow = '0 0 20px rgba(0, 255, 0, 0.7), inset 0 0 10px rgba(0, 255, 0, 0.1)';
        answerElement.style.backgroundColor = 'rgba(0, 255, 0, 0.05)';
    }
    
    answerElement.style.transition = 'all 0.3s ease';
};

// Добавление CSS анимации
const injectStyles = () => {
    if (document.getElementById('quiz-overlay-styles')) return;
    
    const style = document.createElement('style');
    style.id = 'quiz-overlay-styles';
    style.textContent = `
        @keyframes pulse {
            0%, 100% { transform: scale(1); opacity: 1; }
            50% { transform: scale(1.1); opacity: 0.8; }
        }
        
        .quiz-answer-highlighted:hover {
            transform: scale(1.02);
        }
    `;
    document.head.appendChild(style);
};

// Основная функция инициализации overlay помощника
export const initQuizOverlayHelper = async () => {
    if (!isExtensionContextValid()) return;
    
    log('Запуск Quiz Overlay Helper (БЕЗ автоматических запросов)');
    
    // Добавляем стили
    injectStyles();
    
    // Загружаем базу данных
    await loadQuizDatabase();
    if (!quizDatabase) {
        logError('База вопросов не загружена, помощник отключен');
        return;
    }
    
    // Получаем настройки
    const settings = await chrome.storage.sync.get([
        'quizOverlayEnabled',
        'quizSafeMode',
        'quizSubtleMode'
    ]);
    
    if (settings.quizOverlayEnabled === false) {
        log('Quiz overlay отключен в настройках');
        return;
    }
    
    // Безопасный режим - иногда пропускаем вопросы (для естественной статистики)
    if (settings.quizSafeMode && Math.random() < 0.15) {
        log('Safe Mode: Пропускаем этот вопрос для естественности');
        return;
    }
    
    // Ждем появления вопроса
    const questionElement = await waitForElements('.quiz__question', 5000, true);
    if (!questionElement) {
        logWarn('Элемент вопроса не найден');
        return;
    }
    
    const questionText = questionElement.textContent;
    log(`Вопрос обнаружен: "${questionText.substring(0, 60)}..."`);
    
    // Ищем правильный ответ в базе
    const correctAnswer = findCorrectAnswer(questionText);
    if (!correctAnswer) {
        logWarn('Ответ не найден в базе данных');
        return;
    }
    
    // Ищем элементы ответов на странице
    const answerElements = await waitForElements('.quiz__answer', 5000, false);
    if (!answerElements || answerElements.length === 0) {
        logWarn('Элементы ответов не найдены');
        return;
    }
    
    // Находим и подсвечиваем правильный ответ
    for (const answerEl of answerElements) {
        const answerText = answerEl.textContent.trim();
        
        if (normalizeText(answerText) === normalizeText(correctAnswer)) {
            log('Подсвечиваем правильный ответ');
            createAnswerOverlay(answerEl, settings.quizSubtleMode);
            break;
        }
    }
};

// Очистка overlay при уходе со страницы
export const cleanupQuizOverlay = () => {
    document.querySelectorAll('.quiz-helper-overlay').forEach(el => el.remove());
    document.querySelectorAll('.quiz-answer-highlighted').forEach(el => {
        el.classList.remove('quiz-answer-highlighted');
        el.style.boxShadow = '';
        el.style.border = '';
    });
    document.getElementById('quiz-overlay-styles')?.remove();
};

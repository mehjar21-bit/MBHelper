const fs = require('fs');

// Читаем весь файл как одну строку
let content = fs.readFileSync('text скрипта.txt', 'utf-8');

// Убираем переносы строк внутри вопросов/ответов
content = content.replace(/\r?\n/g, ' ');

// Ищем все записи формата: "вопрос", answer: "ответ" },
const regex = /"([^"]+(?:"[^"]*"[^"]*)*?)",\s*answer:\s*"([^"]+)"\s*[,}]/g;
const matches = [];
let match;

// Простой подход: разделяем по }, и обрабатываем каждую запись
const entries = content.split(' },');

for (const entry of entries) {
    if (!entry.trim()) continue;
    
    // Ищем ", answer: "
    const answerSplit = entry.split(', answer: ');
    if (answerSplit.length !== 2) continue;
    
    // Извлекаем вопрос (убираем первую кавычку)
    let question = answerSplit[0].trim();
    if (question.startsWith('"')) question = question.substring(1);
    if (question.endsWith('"')) question = question.slice(0, -1);
    
    // Извлекаем ответ (убираем кавычки)
    let answer = answerSplit[1].trim();
    if (answer.startsWith('"')) answer = answer.substring(1);
    if (answer.endsWith('"')) answer = answer.slice(0, -1);
    
    if (question && answer) {
        matches.push({
            question: question,
            correct_answer: answer
        });
    }
}

// Создаем JSON структуру
const quizData = {
    quiz_database: matches
};

// Сохраняем в файл
fs.writeFileSync('quiz_answers.json', JSON.stringify(quizData, null, 2), 'utf-8');

console.log(`✅ Создано ${matches.length} вопросов!`);
console.log('\n📝 Примеры первых 5:');
for (let i = 0; i < Math.min(5, matches.length); i++) {
    const q = matches[i].question;
    const a = matches[i].correct_answer;
    console.log(`${i+1}. Q: ${q.length > 70 ? q.substring(0, 70) + '...' : q}`);
    console.log(`   A: ${a}`);
    console.log('');
}

